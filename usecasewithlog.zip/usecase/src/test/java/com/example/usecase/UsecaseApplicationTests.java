package com.example.usecase;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UsecaseApplicationTests {

	@Test
	void contextLoads() {
	}

}
