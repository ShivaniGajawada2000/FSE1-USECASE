package com.example.usecase.controller;

import com.example.usecase.dto.Forgot;
import com.example.usecase.dto.Login;
import com.example.usecase.exception.UserAlreadyExist;
import com.example.usecase.exception.UserNameOrPasswordNotCorrect;
import com.example.usecase.model.User;
import com.example.usecase.repository.UserRepository;
import com.example.usecase.service.UserService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@Slf4j
@RestController
@RequestMapping("/api/v1.0/shopping")
public class UserController {

   @Autowired
    UserService userService;

    @PostMapping("/register")
    public ResponseEntity<String> register(@RequestBody User user) throws UserAlreadyExist {
        log.info("Calling register user end point");
       return ResponseEntity.ok(userService.register(user));

    }

    @GetMapping("/login")
    public ResponseEntity<String> login(@RequestBody Login login) throws UserNameOrPasswordNotCorrect {

        log.info("Calling login end point");
     return ResponseEntity.ok(userService.login(login));

//        return ResponseEntity.ok("Login page");
    }

    @GetMapping("/forgot")
    public String logout(@RequestBody Forgot forgotInfo){
        log.info("calling forgot password endpoint");
        return userService.forgotPassword(forgotInfo.getEmail(), forgotInfo.getNewPassword());
    }




    @GetMapping("/public")
    public String publica(){
        log.debug("A DEBUG Message");
        log.info("An INFO Message");
        log.warn("A WARN Message");
        log.error("An ERROR Message");
        return "Yes I am public";
    }

    @GetMapping("/admin")
    public String admin(){
        return "Admin page";
    }

    @GetMapping("/user")
    public String user(){
        return "User page";
    }

    @GetMapping("/demo")
    public String demo(){
        return "Demo page";
    }

}
