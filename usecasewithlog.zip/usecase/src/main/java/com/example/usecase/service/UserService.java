package com.example.usecase.service;

import com.example.usecase.dto.Login;
import com.example.usecase.exception.UserAlreadyExist;
import com.example.usecase.exception.UserNameOrPasswordNotCorrect;
import com.example.usecase.model.User;
import org.springframework.stereotype.Service;

public interface UserService {

    public String register(User user) throws UserAlreadyExist;

    public String login(Login login) throws UserNameOrPasswordNotCorrect;

    public String forgotPassword(String email, String newPassword);


}
