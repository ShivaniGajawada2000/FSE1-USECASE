package com.example.online.shopping.exception;

public class UserNameOrPasswordNotCorrect extends Throwable {
    public UserNameOrPasswordNotCorrect(String msg) {
        super(msg);
    }
}
