package com.example.online.shopping.exception;

public class NoProductExists extends Throwable {
    public NoProductExists(String msg) {
        super(msg);
    }
}
